
<form method="POST" action="index.php">
	<li><label> <?php echo $_SESSION['name']; ?> қош келдіңіз!!!</label></li>
	<li><input type="submit" name="logout" value="Шығу"></li>
</form>
