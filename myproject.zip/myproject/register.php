<?php
session_start();

	if (isset($_GET['act'])) {
		$header = "Бейне - курсты көру үшін тіркеліңіз!!!";
	}
	else{
		$header = "Тіркелді";
	}
 ?>
<!DOCTYPE html>

</html>
<html>

	</body>
</html>
<head>

<meta http-equiv="Content-Type" content="text/html"; charset="utf-8" />
<title>MaSa-S</title>
<link href="stylesheet/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="container">
	<?php include 'header.php'; ?>


	<div class="workzone-right">
			<div>
				<h1><?php echo "$header"; ?></h1>
				<div class="newszone">
					<div>
						<form method="POST" action="index.php">
							<div class="newssubheading">Аты</div>
							<input type="text" name="name" placeholder="аты" required>
							<div class="newssubheading">Тегі</div>
							<input type="text" name="surname" placeholder="тегі" required>
							<div class="newssubheading">Е-Пошта</div>
							<input type="text" name="email" placeholder="е-пошта" required>
							<div class="newssubheading">құпия сөз</div>
							<input type="password" name="password" placeholder="кұпия сөз" required>
							<input type="submit" name="register" value="Тіркелу">
						</form>

					</div>
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div>
	<div class="clear"></div>
</div>
<div class="clear"></div>
<div class="footer">
	<div class="footerinside">
		<div class="footerlink">
			Авторлық құқық (c) Masa-S.kz Барлық құқықтар сақталған.
		</div>
	</div>
</div>
<div class="clear"></div>
</body>
</html>
