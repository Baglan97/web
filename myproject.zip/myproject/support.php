<?php session_start() ?>
<!DOCTYPE html>

</html>
<html>

	</body>
</html>
<head>

<meta http-equiv="Content-Type" content="text/html"; charset="utf-8" />
<title>MaSa-S</title>
<link href="stylesheet/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="container">
	<?php include 'header.php'; ?>
	<div class="clear"></div>
	<div class="questions">
		<div class="logozone">
			<a href="index.html"><img src="images/logom.png" alt="" border="0" /></a>
		</div>
	</div>
	<div class="clear"></div>
	<div class="workzone">
	  <div class="workzone-left">
			<div>
				<h1>Сұрақ-Жауап</h1>
		</div>
			<div class="clear"></div>
			<div>
              <div class="ourprojectrow"> <img src="images/ico-support.png" width="144" height="117" align="right" alt="Support/FAQ" />
                  <div class="blog-posted-row">04. Желтоқсан, 2015 <a href="#">админ</a></div>
                <div>

                </div>
                <div><a href="#">Пікір оқу</a></div>
              </div>
			  <div class="ourprojectrow">
                <h4>Алғашқы сұрақ</h4>
			    <div class="blog-posted-row">04. Желтоқсан, 2015 <a href="#">zhorik97</a></div>
			      </div>
	    </div>
	  </div>
		<div class="workzone-right">
			<div>
				<h1>Жаңалықтар</h1>
				<div class="newszone">
					<div>
						<div>
							<div class="newssubheading">8-ші Наурыз, 2016</div>
							<div class="newscontent">
								8 - Наурыз халықаралық әйелдер күні құтты болсын!!! Алматы қаласында әйелдер мейрамы қарсаңында MaSa-s студиясы атынан жаңа шоу өтті!
							</div>
						</div>
						<div>
							<div class="newssubheading">28-ші Ақпан, 2016</div>
							<div class="newscontent">
								Сүлейман Демирел Университетінде ақпараттық жүйлер мамандығы арасында "Hackoton" сайысы болды. Сайыс Web - бағдарламалау мен Бағдарламалау бағытында болды. Жалпы сайысқа 27 топ қатысып, үлкен дәрежеде өтті.  </div>
						</div>
						<div>
							<div class="newssubheading">18-ші Қаңтар, 2016</div>
							<div class="newscontent">
								18 - ші ақпан күні Сүлейман Демирел Университетінде барлық студенттерге 2-ші семестр өтетінін хабарлаймыз. Баршаңызға жоғарғы деңгейдегі білім алуларыңызға тілектеспіз.  </div>
						</div>


					</div>
				</div>
				<div class="clear"></div>
			</div>
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
<div class="clear"></div>
<div class="footer">
	<div class="footerinside">
		<div class="footerlink">
			Авторлық құқық (c) Masa-S.kz Барлық құқықтар сақталған.
		</div>
	</div>
</div>
<div class="clear"></div>
</body>
</html>
