<div class="header">
    <div class="topmenu">
      <ul>
        <?php if (isset($_SESSION['id'])) {
          include 'logged.php';
        }
         ?>
         <?php if (!isset($_SESSION['id'])) { include 'login.php'; }?>
         
        
        <li><a href="aboutus.php">Біз туралы</a></li>
        <li><a href="projects.php">Жобалар</a></li>
        <li><a href="tutorials.php">3D Галерея</a></li>
        <li><a href="services.php">Курстар</a></li>
        <li><a href="support.php">Сұрақ-Жауап</a></li>
        <li><a href="http://sdu.edu.kz">Біздің демеушіміз</a></li>
        <li style="border:none;"><a href="contact.php">Байланыс</a></li>
        
        
      </ul>
    </div>
      
  </div>