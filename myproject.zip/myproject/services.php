<?php session_start() ;
	if (isset($_SESSION['id'])) {
		
	}
	else{
		header("Location: register.php?act=0");
	}
?>
<!DOCTYPE html>

</html>
<html>

	</body>
</html>
<head>

<meta http-equiv="Content-Type" content="text/html"; charset="utf-8" />
<title>MaSa-S</title>
<link href="stylesheet/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="container">
	<?php include 'header.php'; ?>
	<div class="clear"></div>
	<div class="tutorials">

	</div>
	<div class="clear"></div>
	<div class="workzone">
	  <div class="workzone-left">
			<div>
				<h1>Сіздерге арналған курстар</h1>
		</div>
			<div class="clear"></div>
			<div style="padding-bottom:10px;">
              <div> </div>
			  <div class="clear"></div>
			  <div class="clear"></div>

			    <div class="clear"></div>
		      </div>
			  <div style="padding-top:10px;" > </div>
	    </div>
	  </div>
		<div class="workzone-right">
			<div>
				<h1>Жаңалықтар</h1>
				<div class="newszone">
					<div>
						<div>
							<div class="newssubheading">8-ші Наурыз, 2016</div>
							<div class="newscontent">
								8 - Наурыз халықаралық әйелдер күні құтты болсын!!! Алматы қаласында әйелдер мейрамы қарсаңында MaSa-s студиясы атынан жаңа шоу өтті!
							</div>
						</div>
						<div>
							<div class="newssubheading">28-ші Ақпан, 2016</div>
							<div class="newscontent">
								Сүлейман Демирел Университетінде ақпараттық жүйлер мамандығы арасында "Hackoton" сайысы болды. Сайыс Web - бағдарламалау мен Бағдарламалау бағытында болды. Жалпы сайысқа 27 топ қатысып, үлкен дәрежеде өтті.  </div>
						</div>
						<div>
							<div class="newssubheading">18-ші Қаңтар, 2016</div>
							<div class="newscontent">
								18 - ші ақпан күні Сүлейман Демирел Университетінде барлық студенттерге 2-ші семестр өтетінін хабарлаймыз. Баршаңызға жоғарғы деңгейдегі білім алуларыңызға тілектеспіз.  </div>
						</div>

					</div>
				</div>
				<div class="clear"></div>
			</div>
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
<div class="clear"></div>
<div class="footer">
	<div class="footerinside">
		<div class="footerlink">
			Авторлық құқық (c) Masa-S.kz Барлық құқықтар сақталған.
		</div>
	</div>
</div>
<div class="clear"></div>
</body>
</html>
