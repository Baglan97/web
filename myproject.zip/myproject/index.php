<?php
	session_start();
	include 'connection.php';
	include 'functions.php';
	if (isset($_POST['register'])) {
		$email = $_POST['email'];
	    $name = $_POST['name'];
	    $surname = $_POST['surname'];
	    $password = $_POST['password'];

	    $sql="SELECT * FROM users WHERE email='$email'";
	    $result=mysqli_query($conn,$sql);
	    $row = $result->fetch_assoc();
	    if (is_null($row)){
	      $sql = "INSERT INTO users (email,name,surname,password) VALUES ('$email','$name','$surname','$password')";
	      mysqli_query($conn,$sql);
	      header("Location: index.php");
	    }
	    else{
	      header("Location: register.php");
	    }
	}
	elseif (isset($_POST['login'])) {
		$email = $_POST['email'];
		$password = $_POST['password'];
		$url = $_POST['url'];
		$result = loginCheck($email,$password);
		if ($result) {
			$_SESSION['id'] = $result['id'];
			$_SESSION['name'] = $result['name'];
			$_SESSION['surname'] = $result['surnames'];
			header("Location: index.php");
		}
		else{
			header("Location: $url");
		}
	}
	elseif (isset($_POST['logout'])) {
		session_destroy();
		header("Location: index.php");
	}
	else{
		include 'main.php';
	}
 ?>
