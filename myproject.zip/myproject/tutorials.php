<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Models</title>
  </head>
  <body>
    <p>

    <iframe width="1280" height="720" src="https://sketchfab.com/models/50aea64ebf984618b4622cc12dc6a1e3/embed" frameborder="0" allowfullscreen mozallowfullscreen="true" webkitallowfullscreen="true" onmousewheel=""></iframe><p style="font-size: 13px; font-weight: normal; margin: 5px; color: #4A4A4A;">
    <a href="https://sketchfab.com/models/50aea64ebf984618b4622cc12dc6a1e3?utm_medium=embed&utm_source=website&utm_campain=share-popup" target="_blank" style="font-weight: bold; color: #1CAAD9;">3</a>
    by <a href="https://sketchfab.com/baglan?utm_medium=embed&utm_source=website&utm_campain=share-popup" target="_blank" style="font-weight: bold; color: #1CAAD9;">baglan</a>
    on <a href="https://sketchfab.com?utm_medium=embed&utm_source=website&utm_campain=share-popup" target="_blank" style="font-weight: bold; color: #1CAAD9;">Sketchfab</a>
</p>


  </body>
</html>
