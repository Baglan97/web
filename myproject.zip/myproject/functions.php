<?php
	function loginCheck($email,$password){
		include 'connection.php';
		$sql="SELECT * FROM users WHERE email='$email'";
		$result=$conn->query($sql);
		$row = $result->fetch_assoc();
		if (!is_null($row) && $password==$row['password']) {
			return $row;
		}
		else return false;
	}
	
?>