<form method="POST" action="index.php">
	<li><input type="text" name="email"></li>
	<li><input type="password" name="password"></li>
	<li><input type="hidden" name="url" value=<?php $url = str_replace("/myproject/","",$_SERVER['REQUEST_URI']) ; echo $url; ?>></li>
	<li><input type="submit" name="login" value="Кіру"></li>
	<li><a href="register.php">Тіркелу</a></li>
</form>
