<?php session_start()?> 

<!DOCTYPE html>

</html>
<html>

	</body>
</html>
<head>

<meta http-equiv="Content-Type" content="text/html"; charset="utf-8" />
<title>MaSa-S</title>
<link href="stylesheet/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="container">
	<?php include 'header.php'; ?>
	<div class="clear"></div>
	<div class="contactus">
		<div class="logozone">

		</div>
	</div>
	<div class="clear"></div>
	<div class="workzone">
	  <div class="workzone-left">
			<div>
				<h1>Байланыс</h1>
		</div>
			<div class="clear"></div>
			<div style="margin-bottom:10px;">
              <div> <strong>Сіз бізге төмендегі ақпараттар арқылы хабарласа аласыз. Студиямыз 24 сағат жұмыс жасағандықтан кез келген уақытта хабарласа беріңіз. </strong><br />
                  <br />
               </div>
			  <div> <br />
                  <h4>Байланысу үлгісі:</h4>
			    <form method="post">
                    <table width="97%">
                        <tr>
                          <td width="145" align="left" valign="top" class="body" id="Company"><strong>Компания:</strong></td>
                          <td width="280" align="left" valign="top"><input name="Company" type="text" size="40" /></td>
                        </tr>
                        <tr>
                          <td align="left" valign="top" class="body" id="Contact"><strong>Аты-жөні:</strong></td>
                          <td align="left" valign="top"><input name="Name" type="text" size="40" /></td>
                        </tr>
                        <tr>
                          <td align="left" valign="top" class="body" id="Address"><strong>Мекен-жай:
                          </strong></td>
                          <td align="left" valign="top"><input name="Address" type="text" size="40" /></td>
                        </tr>
                        <tr>
                          <td align="left" valign="top" class="body" id="Address"><strong>Subject:
                          </strong></td>
                          <td align="left" valign="top"><input name="subject" type="text" size="40" /></td>
                        </tr>
                        <tr>
                          <td align="left" valign="top" class="body" id="Phone"><strong>
                            Телефон:
                          </strong></td>
                          <td align="left" valign="top"><input name="Phone" type="text" size="40" /></td>
                        </tr>
                        <tr>
                          <td align="left" valign="top" class="body" id="Email"><strong>
                            Пошта:
                          </strong></td>
                          <td align="left" valign="top"><input name="mail" type="text" size="40" /></td>
                        </tr>
                        <tr>
                          <td align="left" valign="top" class="body" id="Comments"><strong>
                            Сұрақтар / Ұсыныстар:
                          </strong></td>
                          <td align="left" valign="top"><textarea name="text" cols="32" rows="6"></textarea></td>
                        </tr>
                        <tr>
                          <td></td>
                          <td><input type="submit" name="email" class="button" value="Send Now" /></td>
                        </tr>
                      </table>
		        </form>
		      </div>
			  <div> <br />
                  <h4>Байланыс ақпараты: </h4>
			    <img src="images/photo-contact.jpg" alt="" width="196" height="130" class="project-img" />
                  <p>1/1 ул.Абылай Хан
Каскелен, Алматы</p>
			    <p> <span><img src="images/ico-phone.png" alt="Phone" width="20" height="16" hspace="2"  /> Телефон:</span> (+7) 771 480 06 70<br />
        <span><img src="images/ico-fax.png" alt="Fax" width="20" height="16" hspace="2"  /> Факс:</span> (+7) 727 307 95 58<br />
        <span><img src="images/ico-website.png" alt="WWW Link" width="20" height="16" hspace="2"  /> Сайт:</span> <a href="#">www.masa-s.kz</a><br />
        <span><img src="images/ico-email.png" alt="Email" width="20" height="16" hspace="2"  /> Пошта:</span> <a href="baglan_97daryn@mail.ru">baglan_97daryn@mail.ru</a><br />
        <span><img src="images/ico-twitter.png" alt="Twitter Follow" width="20" height="16" hspace="3"  /> <a href="#">Твиттерге</a> жазыл</span><br />
                  </p>
		      </div>
	    </div>
	  </div>
		<div class="workzone-right">
			<div>
				<h1>Жаңалықтар</h1>
				<div class="newszone">
					<div>
						<div>
							<div class="newssubheading">8-ші Наурыз, 2016</div>
							<div class="newscontent">
								8 - Наурыз халықаралық әйелдер күні құтты болсын!!! Алматы қаласында әйелдер мейрамы қарсаңында MaSa-s студиясы атынан жаңа шоу өтті!
							</div>
						</div>
						<div>
							<div class="newssubheading">28-ші Ақпан, 2016</div>
							<div class="newscontent">
								Сүлейман Демирел Университетінде ақпараттық жүйлер мамандығы арасында "Hackoton" сайысы болды. Сайыс Web - бағдарламалау мен Бағдарламалау бағытында болды. Жалпы сайысқа 27 топ қатысып, үлкен дәрежеде өтті.  </div>
						</div>
						<div>
							<div class="newssubheading">18-ші Қаңтар, 2016</div>
							<div class="newscontent">
								18 - ші ақпан күні Сүлейман Демирел Университетінде барлық студенттерге 2-ші семестр өтетінін хабарлаймыз. Баршаңызға жоғарғы деңгейдегі білім алуларыңызға тілектеспіз.  </div>
						</div>

						<div class="morenews"><a href="#"><img src="images/more-news.jpg" alt="" border="0" /></a></div>
					</div>
				</div>
				<div class="clear"></div>
			</div>
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
<div class="clear"></div>
<div class="footer">
	<div class="footerinside">
		<div class="footerlink">
			Авторлық құқық (c) Masa-S.kz Барлық құқықтар сақталған.
		</div>
	</div>
</div>
<div class="clear"></div>
</body>
</html>
