<?php session_start() ?>
<!DOCTYPE html>

</html>
<html>

	</body>
</html>
<head>

<meta http-equiv="Content-Type" content="text/html"; charset="utf-8" />
<title>MaSa-S</title>
<link href="stylesheet/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="container">
	<?php include 'header.php'; ?>
	<div class="clear"></div>
	<div>
		<video width="950px" autoplay height="500px" loop="loop">
<source src="Title.ogg" type="video/ogg">
	<source src="Titiulni.mp4" type="video/mp4">
		</video>
	</div>
	<div class="clear"></div>
	<div class="workzone">
	  <div class="workzone-left">
			<div>
				<h1>Our<span class="redheading"> Projects</span></h1>
		</div>
			<div class="clear"></div>
			<div style="padding-bottom:10px;">
              <div class="ourprojectrow">
                <h4>1-ші сабақ</h4>
                <div> <img src="images/projectimg1.jpg" alt="" width="210" height="139" class="project-img" />Тоғызқұмалақ – әлемдік мәдениетінің озық үлгілерімен бой теңестіре алатын зияткерлік (интеллектуалдық) ойын, логикалық ойлау өнері. Археолог-ғалымдарының пайымдауынша ойынның пайда болу мерзімі 4000 жыл шамасын қамтиды. Жасөспірім ұрпақтың дене шынықтыру тәрбиесімен қатар, ақыл-ойынын дамуына да зор мән берген бабаларымыз осы ойынды ойлап тауып, зердегілік және зияткерлік даму құралы ретінде қолданған.
                  <div class="clear"></div>
                </div>
                <br />
                <div style="font-weight:bold;" ><img src="images/arrow.png" alt="" width="16" height="16" border="0"  /> <a href="#">Жобаны көру</a>
                    <div class="clear"></div>
                </div>
              </div>
			  <div class="ourprojectrow">
                <h4>2-ші сабақ </h4>
			    <div> <img src="images/projectimg2.jpg" alt="" width="210" height="139" class="project-img" /> Тоғызқұмалақ ойынының виртуалды бейнесабағына қош келдіңіздер. Тоғызқұмалақ ойыны ойын тақтайынан, құмалақтардан және тұздықтан тұрады. Тоғызқұмалақ ойыны арнайы тақтада екі адам арасында ойналады . Ойын тақтайы әр түрлі болады. Біз ойын тақтайынының ағаш материалынан тұратын стандартты үлгімен жасалған нұсқасын көрсеттік. Ойын тақтасы – 2 қазан, 18 отау, 162 құмалақтан тұрады  Әр отаудың өзінің аты бар. Олар:  1) Таңдық, 2) көшпелі, 3)Атөтпес , 4) Атсұратар, 5) Бел,  6) Белбасар, 7) Қ андықақпан, 8) Көкмойын, 9) Маңдай.

			      <div class="clear"></div>
		        </div>
			    <br />
                <div style="font-weight:bold;"><img src="images/arrow.png" alt="" width="16" height="16" border="0"  /> <a href="#">Жобаны көру</a>
                    <div class="clear"></div>
                </div>
		      </div>
			  <div class="ourprojectrow">
                <h4>3ші сабақ</h4>
			    <div> <img src="images/projectimg3.jpg" alt="" width="210" height="139" class="project-img" /> Алғашқы жүріс жасаған ойыншыны – бастаушы, қарымта жүріс жасаған ойыншыны – қостаушы деп атайды. Кейде бастаушы үшін – ақжағы, қостаушы үшін қаражағы деген тіркестерді де қолданамыз.  
Жүріс ойыншылар тарапынан кезектесіп жүріледі. Жүрісті кімнің жасайтыны жеребемен немесе қарсыластардың  келісімімен анықталады.
Берілген ойын да бастаушының отаулары төменгі жағында,  ал қазандағы құмалақтар саны жоғарғы жағында орналасқан.

			      <div class="clear"></div>
		        </div>
			    <br />
                <div style="font-weight:bold;"><img src="images/arrow.png" alt="" width="16" height="16" border="0"  /> <a href="#">Жобаны көру</a>
                    <div class="clear"></div>
                </div>
		      </div>
	    </div>
	  </div>
		<div class="workzone-right">
			<div>
				<h1>Жаңалықтар</h1>
				<div class="newszone">
					<div>
						<div>
							<div class="newssubheading">8-ші Наурыз, 2016</div>
							<div class="newscontent">
								8 - Наурыз халықаралық әйелдер күні құтты болсын!!! Алматы қаласында әйелдер мейрамы қарсаңында MaSa-s студиясы атынан жаңа шоу өтті!
							</div>
						</div>
						<div>
							<div class="newssubheading">28-ші Ақпан, 2016</div>
							<div class="newscontent">
								Сүлейман Демирел Университетінде ақпараттық жүйлер мамандығы арасында "Hackoton" сайысы болды. Сайыс Web - бағдарламалау мен Бағдарламалау бағытында болды. Жалпы сайысқа 27 топ қатысып, үлкен дәрежеде өтті.  </div>
						</div>
						<div>
							<div class="newssubheading">18-ші Қаңтар, 2016</div>
							<div class="newscontent">
								18 - ші ақпан күні Сүлейман Демирел Университетінде барлық студенттерге 2-ші семестр өтетінін хабарлаймыз. Баршаңызға жоғарғы деңгейдегі білім алуларыңызға тілектеспіз.  </div>
						</div>

					</div>
				</div>
				<div class="clear"></div>
			</div>
		</div>
		<div class="clear"></div>
	</div>
	<div class="clear"></div>
</div>
<div class="clear"></div>
<div class="footer">
	<div class="footerinside">
		<div class="footerlink">
			Авторлық құқық (c) Masa-S.kz Барлық құқықтар сақталған.
		</div>
	</div>
</div>
<div class="clear"></div>
</body>
</html>
